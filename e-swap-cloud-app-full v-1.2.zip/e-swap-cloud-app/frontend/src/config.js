export const config = {
  useMocks: (import.meta.env.VITE_USE_MOCKS ?? 'true').toLowerCase() === 'true',
  apiBaseUrl: (import.meta.env.VITE_API_BASE_URL ?? '').replace(/\/$/, ''),
  awsRegion: import.meta.env.VITE_AWS_REGION ?? 'eu-west-2',
  userPoolId: import.meta.env.VITE_COGNITO_USER_POOL_ID ?? '',
  userPoolClientId: import.meta.env.VITE_COGNITO_APP_CLIENT_ID ?? ''
};

export function assertCloudConfig() {
  if (config.useMocks) return;

  const missing = [];
  if (!config.apiBaseUrl) missing.push('VITE_API_BASE_URL');
  if (!config.userPoolId) missing.push('VITE_COGNITO_USER_POOL_ID');
  if (!config.userPoolClientId) missing.push('VITE_COGNITO_APP_CLIENT_ID');

  if (missing.length > 0) {
    throw new Error(`Missing frontend environment variables: ${missing.join(', ')}`);
  }
}
