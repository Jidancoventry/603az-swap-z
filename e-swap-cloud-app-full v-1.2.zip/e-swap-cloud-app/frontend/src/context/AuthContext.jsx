import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import {
  confirmSignUp,
  fetchAuthSession,
  fetchUserAttributes,
  getCurrentUser,
  resendSignUpCode,
  signIn,
  signOut,
  signUp
} from 'aws-amplify/auth';
import { config } from '../config.js';

const AuthContext = createContext(null);
const MOCK_USER_KEY = 'eswap_mock_user_v2';

function normalizeGroups(groups) {
  if (Array.isArray(groups)) return groups;
  if (!groups) return [];
  if (typeof groups === 'string') {
    return groups
      .replace(/^\[/, '')
      .replace(/\]$/, '')
      .split(',')
      .map((value) => value.trim().replace(/^['"]|['"]$/g, ''))
      .filter(Boolean);
  }
  return [];
}

async function loadCloudUser() {
  const current = await getCurrentUser();
  const [attributes, session] = await Promise.all([
    fetchUserAttributes(),
    fetchAuthSession()
  ]);

  const tokenPayload = session.tokens?.accessToken?.payload ?? {};
  const groups = normalizeGroups(tokenPayload['cognito:groups']);

  return {
    userId: current.userId,
    username: current.username,
    email: attributes.email ?? current.signInDetails?.loginId ?? '',
    name: attributes.name ?? attributes.email?.split('@')[0] ?? 'E-Swap User',
    groups,
    role: groups.includes('Admin') ? 'Admin' : 'Registered User'
  };
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const refreshUser = useCallback(async () => {
    if (config.useMocks) {
      const stored = localStorage.getItem(MOCK_USER_KEY);
      setUser(stored ? JSON.parse(stored) : null);
      return stored ? JSON.parse(stored) : null;
    }

    try {
      const nextUser = await loadCloudUser();
      setUser(nextUser);
      return nextUser;
    } catch {
      setUser(null);
      return null;
    }
  }, []);

  useEffect(() => {
    refreshUser().finally(() => setLoading(false));
  }, [refreshUser]);

  async function login({ email, password }) {
    if (!email || !password) throw new Error('Email and password are required.');

    if (config.useMocks) {
      const isAdmin = email.toLowerCase().startsWith('admin');
      const nextUser = {
        userId: isAdmin ? 'mock-admin' : `mock-${email.toLowerCase()}`,
        username: email,
        email,
        name: email.split('@')[0] || 'E-Swap User',
        groups: isAdmin ? ['Admin'] : [],
        role: isAdmin ? 'Admin' : 'Registered User'
      };
      localStorage.setItem(MOCK_USER_KEY, JSON.stringify(nextUser));
      setUser(nextUser);
      return nextUser;
    }

    const output = await signIn({ username: email, password });
    if (!output.isSignedIn) {
      const step = output.nextStep?.signInStep ?? 'UNKNOWN';
      throw new Error(`Sign-in requires another step: ${step}`);
    }

    return refreshUser();
  }

  async function register({ name, email, password }) {
    if (!name || !email || !password) {
      throw new Error('Name, email and password are required.');
    }

    if (config.useMocks) {
      return {
        isSignUpComplete: false,
        nextStep: { signUpStep: 'CONFIRM_SIGN_UP' },
        username: email
      };
    }

    return signUp({
      username: email,
      password,
      options: {
        userAttributes: {
          email,
          name
        }
      }
    });
  }

  async function confirmRegistration({ email, code }) {
    if (!email || !code) throw new Error('Email and confirmation code are required.');

    if (config.useMocks) {
      return { isSignUpComplete: true };
    }

    return confirmSignUp({
      username: email,
      confirmationCode: code
    });
  }

  async function resendCode(email) {
    if (!email) throw new Error('Email is required.');
    if (config.useMocks) return { destination: email };
    return resendSignUpCode({ username: email });
  }

  async function logout() {
    if (config.useMocks) {
      localStorage.removeItem(MOCK_USER_KEY);
    } else {
      await signOut();
    }
    setUser(null);
  }

  const value = useMemo(() => ({
    user,
    loading,
    login,
    register,
    confirmRegistration,
    resendCode,
    logout,
    refreshUser,
    isAuthenticated: Boolean(user),
    isAdmin: user?.groups?.includes('Admin') || user?.role === 'Admin'
  }), [user, loading, refreshUser]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used inside AuthProvider.');
  return context;
}
