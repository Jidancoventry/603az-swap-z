const ITEMS_KEY = 'eswap_mock_items_v2';
const REQUESTS_KEY = 'eswap_mock_requests_v2';

const starterItems = [
  {
    itemId: 'itm-demo-1',
    ownerId: 'demo-owner-1',
    ownerName: 'Aisha',
    title: 'Dell Latitude laptop',
    category: 'Laptop',
    description: 'Working business laptop with charger. Battery is usable and Windows is installed.',
    condition: 'Good',
    location: 'Coventry',
    actionType: 'Exchange',
    price: 0,
    tokenValue: 120,
    imageUrl: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=1200&q=80',
    imageKey: '',
    status: 'Active',
    createdAt: '2026-07-10T11:00:00Z',
    updatedAt: '2026-07-10T11:00:00Z'
  },
  {
    itemId: 'itm-demo-2',
    ownerId: 'demo-owner-2',
    ownerName: 'Daniel',
    title: 'PlayStation controller',
    category: 'Console',
    description: 'DualSense controller in good condition. Minor marks but all buttons work.',
    condition: 'Good',
    location: 'London',
    actionType: 'Sell',
    price: 34,
    tokenValue: 40,
    imageUrl: 'https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?auto=format&fit=crop&w=1200&q=80',
    imageKey: '',
    status: 'Active',
    createdAt: '2026-07-11T13:30:00Z',
    updatedAt: '2026-07-11T13:30:00Z'
  },
  {
    itemId: 'itm-demo-3',
    ownerId: 'demo-owner-3',
    ownerName: 'Sam',
    title: 'iPhone 11 for parts',
    category: 'Phone',
    description: 'Screen is damaged and the phone does not power on. Suitable for parts or recycling.',
    condition: 'For Parts',
    location: 'Luton',
    actionType: 'Recycle',
    price: 0,
    tokenValue: 25,
    imageUrl: 'https://images.unsplash.com/photo-1592286927505-1def25115558?auto=format&fit=crop&w=1200&q=80',
    imageKey: '',
    status: 'Active',
    createdAt: '2026-07-12T09:15:00Z',
    updatedAt: '2026-07-12T09:15:00Z'
  }
];

function readJson(key, fallback) {
  const raw = localStorage.getItem(key);
  if (!raw) return fallback;
  try {
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function writeJson(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

export function getMockItems() {
  const items = readJson(ITEMS_KEY, null);
  if (items) return items;
  writeJson(ITEMS_KEY, starterItems);
  return starterItems;
}

export function saveMockItems(items) {
  writeJson(ITEMS_KEY, items);
}

export function getMockRequests() {
  return readJson(REQUESTS_KEY, []);
}

export function saveMockRequests(requests) {
  writeJson(REQUESTS_KEY, requests);
}

export function resetMockData() {
  localStorage.removeItem(ITEMS_KEY);
  localStorage.removeItem(REQUESTS_KEY);
}
