export const categories = [
  'Laptop',
  'Phone',
  'Tablet',
  'Console',
  'Monitor',
  'Accessory',
  'Audio',
  'Other'
];

export const conditions = ['Like New', 'Good', 'Fair', 'For Parts'];
export const actionTypes = ['Exchange', 'Sell', 'Donate', 'Recycle'];
export const requestTypes = ['Exchange', 'Purchase', 'Donation', 'Recycling'];
