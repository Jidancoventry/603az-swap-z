import { Box, ClipboardList, PlusCircle, ShieldCheck } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function DashboardPage() {
  const { user, isAdmin } = useAuth();

  return (
    <section className="section">
      <div className="page-header">
        <div>
          <span className="eyebrow">User dashboard</span>
          <h1>Welcome, {user?.name}</h1>
          <p className="muted">Your account is authenticated and ready to use the cloud API.</p>
        </div>
      </div>

      <div className="dashboard-grid">
        <Link className="dashboard-card" to="/create-listing"><PlusCircle /><h3>Create listing</h3><p>Upload an item image and store a new listing.</p></Link>
        <Link className="dashboard-card" to="/browse"><Box /><h3>Browse marketplace</h3><p>View active cloud-stored listings.</p></Link>
        <Link className="dashboard-card" to="/my-listings"><ClipboardList /><h3>My listings</h3><p>Manage items created by your Cognito identity.</p></Link>
        <Link className="dashboard-card" to="/requests"><ClipboardList /><h3>My requests</h3><p>Track requests you sent or received.</p></Link>
        {isAdmin && <Link className="dashboard-card" to="/admin"><ShieldCheck /><h3>Admin moderation</h3><p>Approve or remove listings using Cognito groups.</p></Link>}
      </div>

      <div className="panel cloud-proof-panel">
        <h2>Cloud proof for your demonstration</h2>
        <p>After creating a listing, show the matching record in DynamoDB, the image object in S3 and the request log in CloudWatch.</p>
      </div>
    </section>
  );
}
