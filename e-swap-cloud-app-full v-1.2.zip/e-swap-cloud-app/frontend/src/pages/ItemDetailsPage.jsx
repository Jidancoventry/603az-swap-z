import { ArrowLeft, Coins, MapPin, PoundSterling, UserRound } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import StatusBadge from '../components/StatusBadge.jsx';
import { requestTypes } from '../data/constants.js';
import { useAuth } from '../context/AuthContext.jsx';
import { api } from '../services/api.js';

const placeholder = 'https://images.unsplash.com/photo-1523206489230-c012c64b2b48?auto=format&fit=crop&w=1200&q=80';

export default function ItemDetailsPage() {
  const { itemId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [item, setItem] = useState(null);
  const [requestForm, setRequestForm] = useState({ requestType: 'Exchange', message: '' });
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    api.getItem(itemId)
      .then(setItem)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [itemId]);

  async function handleRequest(event) {
    event.preventDefault();
    if (!user) {
      navigate('/login', { state: { from: { pathname: `/items/${itemId}` } } });
      return;
    }
    setError('');
    setMessage('');
    setSubmitting(true);
    try {
      await api.createRequest({ itemId, ...requestForm });
      setMessage('Request sent successfully.');
      setRequestForm({ ...requestForm, message: '' });
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) return <div className="page-loading">Loading item…</div>;
  if (error && !item) return <section className="section"><p className="error-text">{error}</p></section>;

  const isOwner = user?.userId === item.ownerId;

  return (
    <section className="section">
      <Link className="back-link" to="/browse"><ArrowLeft size={18} /> Back to browse</Link>
      <div className="details-layout">
        <div className="details-image-panel panel">
          <img src={item.imageUrl || placeholder} alt={item.title} onError={(event) => { event.currentTarget.src = placeholder; }} />
        </div>
        <div className="details-copy panel">
          <div className="item-meta-row"><span>{item.category}</span><span>{item.condition}</span></div>
          <h1>{item.title}</h1>
          <p className="lead">{item.description}</p>
          <div className="details-list">
            <span><MapPin /> {item.location}</span>
            <span><UserRound /> Listed by {item.ownerName || 'E-Swap user'}</span>
            {item.actionType === 'Sell' && Number(item.price) > 0
              ? <span><PoundSterling /> {Number(item.price).toFixed(2)}</span>
              : <span><Coins /> {item.tokenValue || 0} tokens</span>}
          </div>
          <div className="inline-badges"><span className={`badge badge-${item.actionType.toLowerCase()}`}>{item.actionType}</span><StatusBadge value={item.status} /></div>

          {!isOwner ? (
            <form className="request-box" onSubmit={handleRequest}>
              <h2>Send a request</h2>
              <label>Request type
                <select value={requestForm.requestType} onChange={(event) => setRequestForm({ ...requestForm, requestType: event.target.value })}>
                  {requestTypes.map((value) => <option key={value}>{value}</option>)}
                </select>
              </label>
              <label>Message
                <textarea rows="3" value={requestForm.message} onChange={(event) => setRequestForm({ ...requestForm, message: event.target.value })} maxLength="500" placeholder="Explain your offer or collection request." required />
              </label>
              {message && <p className="success-text">{message}</p>}
              {error && <p className="error-text">{error}</p>}
              <button className="btn btn-primary full" disabled={submitting}>{submitting ? 'Sending…' : 'Send request'}</button>
            </form>
          ) : (
            <div className="owner-note">This is your listing. Manage it from <Link to="/my-listings">My listings</Link>.</div>
          )}
        </div>
      </div>
    </section>
  );
}
