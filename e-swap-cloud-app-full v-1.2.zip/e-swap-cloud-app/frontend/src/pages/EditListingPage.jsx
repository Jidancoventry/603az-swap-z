import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { actionTypes, categories, conditions } from '../data/constants.js';
import { api } from '../services/api.js';

export default function EditListingPage() {
  const { itemId } = useParams();
  const navigate = useNavigate();
  const [form, setForm] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    api.getMyItems()
      .then((items) => {
        const item = items.find((entry) => entry.itemId === itemId);
        if (!item) throw new Error('Listing not found or you do not own it.');
        setForm({
        title: item.title,
        category: item.category,
        description: item.description,
        condition: item.condition,
        location: item.location,
        actionType: item.actionType,
        price: item.price || 0,
        tokenValue: item.tokenValue || 0
        });
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [itemId]);

  async function save(event) {
    event.preventDefault();
    setError('');
    setSaving(true);
    try {
      await api.updateItem(itemId, { ...form, price: Number(form.price || 0), tokenValue: Number(form.tokenValue || 0) });
      navigate('/my-listings', { state: { message: 'Listing updated successfully.' } });
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <div className="page-loading">Loading listing…</div>;
  if (!form) return <section className="section"><p className="error-text">{error || 'Listing not found.'}</p></section>;

  return (
    <section className="section narrow-section">
      <div className="page-header"><div><span className="eyebrow">Edit listing</span><h1>Update item details</h1></div></div>
      <form className="panel form" onSubmit={save}>
        <label>Title<input value={form.title} onChange={(event) => setForm({ ...form, title: event.target.value })} required /></label>
        <div className="two-cols">
          <label>Category<select value={form.category} onChange={(event) => setForm({ ...form, category: event.target.value })}>{categories.map((value) => <option key={value}>{value}</option>)}</select></label>
          <label>Condition<select value={form.condition} onChange={(event) => setForm({ ...form, condition: event.target.value })}>{conditions.map((value) => <option key={value}>{value}</option>)}</select></label>
        </div>
        <label>Description<textarea rows="5" value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} required /></label>
        <div className="two-cols">
          <label>Location<input value={form.location} onChange={(event) => setForm({ ...form, location: event.target.value })} required /></label>
          <label>Action<select value={form.actionType} onChange={(event) => setForm({ ...form, actionType: event.target.value })}>{actionTypes.map((value) => <option key={value}>{value}</option>)}</select></label>
        </div>
        <div className="two-cols">
          <label>Price (£)<input type="number" min="0" step="0.01" value={form.price} onChange={(event) => setForm({ ...form, price: event.target.value })} /></label>
          <label>Token value<input type="number" min="0" value={form.tokenValue} onChange={(event) => setForm({ ...form, tokenValue: event.target.value })} /></label>
        </div>
        {error && <p className="error-text">{error}</p>}
        <button className="btn btn-primary full" disabled={saving}>{saving ? 'Saving…' : 'Save changes'}</button>
      </form>
    </section>
  );
}
