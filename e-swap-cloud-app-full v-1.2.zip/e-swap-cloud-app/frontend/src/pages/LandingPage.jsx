import { ArrowRight, Cloud, Leaf, Recycle, Repeat2, ShieldCheck } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function LandingPage() {
  return (
    <>
      <section className="hero section">
        <div className="hero-copy">
          <span className="eyebrow">Responsible electronics marketplace</span>
          <h1>Give electronics a second life.</h1>
          <p>
            E-Swap helps people exchange, sell, donate and recycle unwanted electronics instead of sending them to landfill.
          </p>
          <div className="hero-actions">
            <Link className="btn btn-primary" to="/browse">Browse items <ArrowRight size={18} /></Link>
            <Link className="btn btn-secondary" to="/create-listing">List an item</Link>
          </div>
          <div className="trust-row">
            <span><ShieldCheck size={18} /> Secure user accounts</span>
            <span><Cloud size={18} /> AWS serverless cloud</span>
            <span><Leaf size={18} /> SDG 12 focused</span>
          </div>
        </div>
        <div className="hero-visual">
          <div className="impact-card large">
            <Recycle size={42} />
            <strong>Reuse before recycling</strong>
            <p>Extend the useful life of devices and reduce unnecessary electronic waste.</p>
          </div>
          <div className="impact-card floating">
            <Repeat2 size={28} />
            <strong>Exchange locally</strong>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="section-heading centered">
          <span className="eyebrow">How it works</span>
          <h2>A complete cloud-based reuse journey</h2>
        </div>
        <div className="feature-grid">
          <article className="feature-card"><span>1</span><h3>Create an account</h3><p>Register and verify your email through Amazon Cognito.</p></article>
          <article className="feature-card"><span>2</span><h3>List a device</h3><p>Upload an image to S3 and save item details in DynamoDB.</p></article>
          <article className="feature-card"><span>3</span><h3>Connect and reuse</h3><p>Send a purchase, exchange, donation or recycling request.</p></article>
        </div>
      </section>
    </>
  );
}
