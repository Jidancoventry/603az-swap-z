import { Pencil, PlusCircle, Trash2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import EmptyState from '../components/EmptyState.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import { api } from '../services/api.js';

export default function MyListingsPage() {
  const location = useLocation();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState(location.state?.message || '');
  const [error, setError] = useState('');

  function load() {
    setLoading(true);
    api.getMyItems()
      .then(setItems)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  async function remove(itemId) {
    if (!window.confirm('Delete this listing permanently?')) return;
    setError('');
    try {
      await api.deleteItem(itemId);
      setItems((current) => current.filter((entry) => entry.itemId !== itemId));
      setMessage('Listing deleted.');
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <section className="section">
      <div className="page-header split-header">
        <div><span className="eyebrow">My listings</span><h1>Manage your electronic items</h1><p className="muted">Ownership is checked using the Cognito user ID in the JWT.</p></div>
        <Link className="btn btn-primary" to="/create-listing"><PlusCircle size={18} /> New listing</Link>
      </div>
      {message && <p className="success-text">{message}</p>}
      {error && <p className="error-text">{error}</p>}
      {loading && <div className="page-loading">Loading your listings…</div>}
      {!loading && items.length === 0 && <EmptyState title="You have no listings" description="Create an item to demonstrate cloud persistence." />}
      {!loading && items.length > 0 && (
        <div className="panel table-wrap">
          <table>
            <thead><tr><th>Item</th><th>Action</th><th>Status</th><th>Created</th><th>Manage</th></tr></thead>
            <tbody>
              {items.map((item) => (
                <tr key={item.itemId}>
                  <td><Link to={`/items/${item.itemId}`}>{item.title}</Link><small>{item.category} · {item.condition}</small></td>
                  <td>{item.actionType}</td>
                  <td><StatusBadge value={item.status} /></td>
                  <td>{new Date(item.createdAt).toLocaleDateString()}</td>
                  <td className="table-actions">
                    <Link className="icon-button" title="Edit" to={`/edit-listing/${item.itemId}`}><Pencil size={17} /></Link>
                    <button className="icon-button danger" title="Delete" onClick={() => remove(item.itemId)}><Trash2 size={17} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
