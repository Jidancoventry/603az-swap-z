import { useEffect, useState } from 'react';
import StatusBadge from '../components/StatusBadge.jsx';
import { api } from '../services/api.js';

export default function AdminPage() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    api.getAdminItems()
      .then(setItems)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  async function moderate(itemId, status) {
    setError('');
    setMessage('');
    try {
      const updated = await api.moderateItem(itemId, status);
      setItems((current) => current.map((entry) => entry.itemId === itemId ? { ...entry, ...updated } : entry));
      setMessage(`Listing set to ${status}.`);
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <section className="section">
      <div className="page-header"><div><span className="eyebrow">Admin only</span><h1>Listing moderation</h1><p className="muted">The backend checks the Cognito Admin group; hiding the page in React is not the security control.</p></div></div>
      {message && <p className="success-text">{message}</p>}
      {error && <p className="error-text">{error}</p>}
      {loading && <div className="page-loading">Loading moderation queue…</div>}
      {!loading && (
        <div className="panel table-wrap">
          <table>
            <thead><tr><th>Title</th><th>Owner</th><th>Action</th><th>Status</th><th>Moderate</th></tr></thead>
            <tbody>
              {items.map((item) => (
                <tr key={item.itemId}>
                  <td>{item.title}<small>{item.category} · {item.location}</small></td>
                  <td>{item.ownerName || item.ownerId}</td>
                  <td>{item.actionType}</td>
                  <td><StatusBadge value={item.status} /></td>
                  <td className="table-actions">
                    <button className="btn btn-primary small" onClick={() => moderate(item.itemId, 'Active')}>Approve</button>
                    <button className="btn btn-danger small" onClick={() => moderate(item.itemId, 'Removed')}>Remove</button>
                    <button className="btn btn-secondary small" onClick={() => moderate(item.itemId, 'Pending')}>Pending</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
