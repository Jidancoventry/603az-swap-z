import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { actionTypes, categories, conditions } from '../data/constants.js';
import { api } from '../services/api.js';

const initialForm = {
  title: '',
  category: 'Laptop',
  description: '',
  condition: 'Good',
  location: '',
  actionType: 'Exchange',
  price: 0,
  tokenValue: 50
};

export default function CreateListingPage() {
  const [form, setForm] = useState(initialForm);
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState('');
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => () => {
    if (preview?.startsWith('blob:')) URL.revokeObjectURL(preview);
  }, [preview]);

  function handleImage(event) {
    const selected = event.target.files?.[0];
    setError('');
    if (!selected) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(selected.type)) {
      setError('Use a JPG, PNG or WebP image.');
      return;
    }
    if (selected.size > 5 * 1024 * 1024) {
      setError('The image must be 5 MB or smaller.');
      return;
    }
    if (preview?.startsWith('blob:')) URL.revokeObjectURL(preview);
    setFile(selected);
    setPreview(URL.createObjectURL(selected));
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setError('');
    setLoading(true);
    try {
      let imageKey = '';
      let imageUrl = '';

      if (file) {
        setProgress('Requesting secure S3 upload URL…');
        const upload = await api.createUploadUrl(file);
        imageKey = upload.imageKey;
        imageUrl = upload.mockImageUrl || '';
        if (upload.uploadUrl) {
          setProgress('Uploading image directly to S3…');
          await api.uploadFile(file, upload.uploadUrl);
        }
      }

      setProgress('Saving listing through API Gateway and Lambda…');
      await api.createItem({
        ...form,
        price: Number(form.price || 0),
        tokenValue: Number(form.tokenValue || 0),
        imageKey,
        imageUrl
      });
      navigate('/my-listings', { state: { message: 'Listing created successfully.' } });
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
      setProgress('');
    }
  }

  return (
    <section className="section">
      <div className="page-header">
        <div>
          <span className="eyebrow">Create listing</span>
          <h1>List an electronic item</h1>
          <p className="muted">The image is uploaded to S3, then listing data is stored in DynamoDB.</p>
        </div>
      </div>

      <div className="form-layout">
        <form className="panel form" onSubmit={handleSubmit}>
          <label>Item title
            <input value={form.title} onChange={(event) => setForm({ ...form, title: event.target.value })} maxLength="100" required />
          </label>
          <div className="two-cols">
            <label>Category
              <select value={form.category} onChange={(event) => setForm({ ...form, category: event.target.value })}>{categories.map((value) => <option key={value}>{value}</option>)}</select>
            </label>
            <label>Condition
              <select value={form.condition} onChange={(event) => setForm({ ...form, condition: event.target.value })}>{conditions.map((value) => <option key={value}>{value}</option>)}</select>
            </label>
          </div>
          <label>Description
            <textarea rows="5" value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} maxLength="1000" required />
          </label>
          <div className="two-cols">
            <label>Location
              <input value={form.location} onChange={(event) => setForm({ ...form, location: event.target.value })} maxLength="80" required />
            </label>
            <label>Preferred action
              <select value={form.actionType} onChange={(event) => setForm({ ...form, actionType: event.target.value })}>{actionTypes.map((value) => <option key={value}>{value}</option>)}</select>
            </label>
          </div>
          <div className="two-cols">
            <label>Price (£)
              <input type="number" min="0" step="0.01" value={form.price} onChange={(event) => setForm({ ...form, price: event.target.value })} disabled={form.actionType !== 'Sell'} />
            </label>
            <label>Token value
              <input type="number" min="0" value={form.tokenValue} onChange={(event) => setForm({ ...form, tokenValue: event.target.value })} />
            </label>
          </div>
          <label>Item image
            <input type="file" accept="image/jpeg,image/png,image/webp" onChange={handleImage} />
          </label>
          {progress && <p className="progress-text">{progress}</p>}
          {error && <p className="error-text">{error}</p>}
          <button className="btn btn-primary full" disabled={loading}>{loading ? 'Creating listing…' : 'Create listing'}</button>
        </form>

        <aside className="panel preview-panel">
          <h2>Preview</h2>
          {preview ? <img src={preview} alt="Listing preview" /> : <div className="image-placeholder">Select an image</div>}
          <h3>{form.title || 'Your item title'}</h3>
          <p>{form.description || 'Your description will appear here.'}</p>
          <span className="status status-pending">New listing</span>
        </aside>
      </div>
    </section>
  );
}
