import { useEffect, useState } from 'react';
import EmptyState from '../components/EmptyState.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { api } from '../services/api.js';

export default function RequestsPage() {
  const { user } = useAuth();
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  function load() {
    setLoading(true);
    api.getMyRequests()
      .then(setRequests)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  async function update(requestId, status) {
    setError('');
    setMessage('');
    try {
      const updated = await api.updateRequest(requestId, status);
      setRequests((current) => current.map((entry) => entry.requestId === requestId ? updated : entry));
      setMessage(`Request changed to ${status}.`);
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <section className="section">
      <div className="page-header"><div><span className="eyebrow">Requests</span><h1>Sent and received requests</h1><p className="muted">A complete user-to-user workflow stored in DynamoDB.</p></div></div>
      {message && <p className="success-text">{message}</p>}
      {error && <p className="error-text">{error}</p>}
      {loading && <div className="page-loading">Loading requests…</div>}
      {!loading && requests.length === 0 && <EmptyState title="No requests yet" description="Open another user's listing and send an exchange, purchase, donation or recycling request." />}
      {!loading && requests.length > 0 && (
        <div className="request-grid">
          {requests.map((entry) => {
            const received = entry.ownerId === user.userId;
            return (
              <article className="panel request-card" key={entry.requestId}>
                <div className="request-card-head"><div><span className="eyebrow">{received ? 'Received' : 'Sent'} · {entry.requestType}</span><h3>{entry.itemTitle}</h3></div><StatusBadge value={entry.status} /></div>
                <p>{entry.message}</p>
                <small>{new Date(entry.createdAt).toLocaleString()}</small>
                {received && entry.status === 'Pending' && <div className="button-row"><button className="btn btn-primary small" onClick={() => update(entry.requestId, 'Accepted')}>Accept</button><button className="btn btn-danger small" onClick={() => update(entry.requestId, 'Rejected')}>Reject</button></div>}
                {!received && entry.status === 'Pending' && <button className="btn btn-secondary small" onClick={() => update(entry.requestId, 'Cancelled')}>Cancel request</button>}
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
}
