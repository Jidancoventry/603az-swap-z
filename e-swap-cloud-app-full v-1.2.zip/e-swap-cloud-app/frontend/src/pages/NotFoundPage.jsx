import { Link } from 'react-router-dom';

export default function NotFoundPage() {
  return <section className="section centered-page"><h1>Page not found</h1><p>The page you requested does not exist.</p><Link className="btn btn-primary" to="/">Return home</Link></section>;
}
