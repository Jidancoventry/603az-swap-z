import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function RegisterPage() {
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { register } = useAuth();
  const navigate = useNavigate();

  async function handleSubmit(event) {
    event.preventDefault();
    setError('');
    setLoading(true);
    try {
      const result = await register(form);
      if (result.isSignUpComplete) {
        navigate('/login');
      } else {
        navigate(`/confirm?email=${encodeURIComponent(form.email)}`);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="section auth-section">
      <form className="panel auth-card" onSubmit={handleSubmit}>
        <span className="eyebrow">Create an account</span>
        <h1>Join E-Swap</h1>
        <label>Full name
          <input value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} required />
        </label>
        <label>Email
          <input type="email" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} required />
        </label>
        <label>Password
          <input type="password" value={form.password} onChange={(event) => setForm({ ...form, password: event.target.value })} minLength="8" required />
        </label>
        <p className="hint">Use at least 8 characters with uppercase, lowercase, number and symbol.</p>
        {error && <p className="error-text">{error}</p>}
        <button className="btn btn-primary full" disabled={loading}>{loading ? 'Creating account…' : 'Create account'}</button>
        <p className="muted small-text">Already registered? <Link to="/login">Login</Link></p>
      </form>
    </section>
  );
}
