import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function ConfirmPage() {
  const [searchParams] = useSearchParams();
  const [email, setEmail] = useState(searchParams.get('email') || '');
  const [code, setCode] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { confirmRegistration, resendCode } = useAuth();
  const navigate = useNavigate();

  async function handleConfirm(event) {
    event.preventDefault();
    setError('');
    setLoading(true);
    try {
      await confirmRegistration({ email, code });
      navigate('/login', { replace: true });
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleResend() {
    setError('');
    try {
      await resendCode(email);
      setMessage('A new confirmation code was sent.');
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <section className="section auth-section">
      <form className="panel auth-card" onSubmit={handleConfirm}>
        <span className="eyebrow">Verify email</span>
        <h1>Confirm your account</h1>
        <p className="muted">Enter the code Cognito sent to your email.</p>
        <label>Email
          <input type="email" value={email} onChange={(event) => setEmail(event.target.value)} required />
        </label>
        <label>Confirmation code
          <input inputMode="numeric" value={code} onChange={(event) => setCode(event.target.value)} required />
        </label>
        {message && <p className="success-text">{message}</p>}
        {error && <p className="error-text">{error}</p>}
        <button className="btn btn-primary full" disabled={loading}>{loading ? 'Confirming…' : 'Confirm account'}</button>
        <button className="btn btn-secondary full" type="button" onClick={handleResend}>Resend code</button>
        <p className="muted small-text"><Link to="/login">Back to login</Link></p>
      </form>
    </section>
  );
}
