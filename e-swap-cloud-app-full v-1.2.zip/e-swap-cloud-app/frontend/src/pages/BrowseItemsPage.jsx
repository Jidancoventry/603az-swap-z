import { useEffect, useState } from 'react';
import EmptyState from '../components/EmptyState.jsx';
import ItemCard from '../components/ItemCard.jsx';
import { actionTypes, categories, conditions } from '../data/constants.js';
import { api } from '../services/api.js';

export default function BrowseItemsPage() {
  const [filters, setFilters] = useState({ search: '', category: 'All', condition: 'All', actionType: 'All', location: '' });
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let alive = true;
    setLoading(true);
    setError('');
    const timer = setTimeout(() => {
      api.getItems(filters)
        .then((result) => { if (alive) setItems(result); })
        .catch((err) => { if (alive) setError(err.message); })
        .finally(() => { if (alive) setLoading(false); });
    }, 200);

    return () => {
      alive = false;
      clearTimeout(timer);
    };
  }, [filters]);

  return (
    <section className="section">
      <div className="page-header">
        <div>
          <span className="eyebrow">Marketplace</span>
          <h1>Browse electronic items</h1>
          <p className="muted">Only active listings are visible publicly.</p>
        </div>
      </div>

      <div className="filter-bar">
        <input aria-label="Search" placeholder="Search laptop, phone, console…" value={filters.search} onChange={(event) => setFilters({ ...filters, search: event.target.value })} />
        <select aria-label="Category" value={filters.category} onChange={(event) => setFilters({ ...filters, category: event.target.value })}>
          <option>All</option>{categories.map((value) => <option key={value}>{value}</option>)}
        </select>
        <select aria-label="Condition" value={filters.condition} onChange={(event) => setFilters({ ...filters, condition: event.target.value })}>
          <option>All</option>{conditions.map((value) => <option key={value}>{value}</option>)}
        </select>
        <select aria-label="Action" value={filters.actionType} onChange={(event) => setFilters({ ...filters, actionType: event.target.value })}>
          <option>All</option>{actionTypes.map((value) => <option key={value}>{value}</option>)}
        </select>
        <input aria-label="Location" placeholder="Location" value={filters.location} onChange={(event) => setFilters({ ...filters, location: event.target.value })} />
      </div>

      {loading && <div className="page-loading">Loading listings…</div>}
      {error && <p className="error-text">{error}</p>}
      {!loading && !error && items.length === 0 && <EmptyState title="No active listings found" description="Change the filters or create a listing." />}
      {!loading && !error && items.length > 0 && <div className="items-grid">{items.map((item) => <ItemCard key={item.itemId} item={item} />)}</div>}
    </section>
  );
}
