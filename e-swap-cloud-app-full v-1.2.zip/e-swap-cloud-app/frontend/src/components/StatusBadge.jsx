export default function StatusBadge({ value }) {
  const safeValue = value || 'Unknown';
  return <span className={`status status-${safeValue.toLowerCase().replace(/\s+/g, '-')}`}>{safeValue}</span>;
}
