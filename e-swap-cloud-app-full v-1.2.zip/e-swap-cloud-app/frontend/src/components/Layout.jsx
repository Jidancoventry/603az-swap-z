import { Menu, Recycle, X } from 'lucide-react';
import { useState } from 'react';
import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { config } from '../config.js';

const publicLinks = [
  { to: '/browse', label: 'Browse' }
];

const protectedLinks = [
  { to: '/create-listing', label: 'List item' },
  { to: '/my-listings', label: 'My listings' },
  { to: '/requests', label: 'Requests' }
];

export default function Layout() {
  const [open, setOpen] = useState(false);
  const { user, logout, isAdmin } = useAuth();
  const navigate = useNavigate();

  async function handleLogout() {
    await logout();
    navigate('/');
  }

  return (
    <div className="app-shell">
      <header className="navbar">
        <Link className="brand" to="/" onClick={() => setOpen(false)}>
          <span className="brand-icon"><Recycle size={22} /></span>
          <span>E-Swap</span>
        </Link>

        <button className="mobile-menu" aria-label="Toggle navigation" onClick={() => setOpen((value) => !value)}>
          {open ? <X /> : <Menu />}
        </button>

        <nav className={`nav-links ${open ? 'open' : ''}`}>
          <NavLink to="/" onClick={() => setOpen(false)}>Home</NavLink>
          {publicLinks.map((link) => (
            <NavLink key={link.to} to={link.to} onClick={() => setOpen(false)}>{link.label}</NavLink>
          ))}
          {user && protectedLinks.map((link) => (
            <NavLink key={link.to} to={link.to} onClick={() => setOpen(false)}>{link.label}</NavLink>
          ))}
          {isAdmin && <NavLink to="/admin" onClick={() => setOpen(false)}>Admin</NavLink>}
        </nav>

        <div className="nav-actions">
          {user ? (
            <>
              <Link className="btn btn-ghost small" to="/dashboard">{user.name}</Link>
              <button className="btn btn-primary small" onClick={handleLogout}>Logout</button>
            </>
          ) : (
            <>
              <Link className="btn btn-ghost small" to="/login">Login</Link>
              <Link className="btn btn-primary small" to="/register">Register</Link>
            </>
          )}
        </div>
      </header>

      {config.useMocks && (
        <div className="mode-banner">
          Mock mode is active. Set <code>VITE_USE_MOCKS=false</code> after deploying AWS.
        </div>
      )}

      <main><Outlet /></main>

      <footer className="footer">
        <div>
          <strong>E-Swap</strong>
          <p>Give electronics a second life through reuse, exchange, donation and recycling.</p>
        </div>
        <p>React + Amplify Hosting + Cognito + API Gateway + Lambda + DynamoDB + S3</p>
      </footer>
    </div>
  );
}
