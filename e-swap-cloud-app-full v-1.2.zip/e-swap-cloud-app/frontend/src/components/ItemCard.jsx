import { Coins, MapPin, PoundSterling } from 'lucide-react';
import { Link } from 'react-router-dom';
import StatusBadge from './StatusBadge.jsx';

const placeholder = 'https://images.unsplash.com/photo-1523206489230-c012c64b2b48?auto=format&fit=crop&w=1200&q=80';

export default function ItemCard({ item, showStatus = false }) {
  return (
    <article className="item-card">
      <div className="item-image-wrap">
        <img
          src={item.imageUrl || placeholder}
          alt={item.title}
          className="item-image"
          onError={(event) => { event.currentTarget.src = placeholder; }}
        />
        <span className={`badge badge-${item.actionType?.toLowerCase()}`}>{item.actionType}</span>
      </div>
      <div className="item-content">
        <div className="item-meta-row">
          <span>{item.category}</span>
          <span>{item.condition}</span>
        </div>
        <h3>{item.title}</h3>
        <p>{item.description}</p>
        <div className="item-details-row">
          <span><MapPin size={16} /> {item.location}</span>
          {item.actionType === 'Sell' && Number(item.price) > 0
            ? <span><PoundSterling size={16} /> {Number(item.price).toFixed(2)}</span>
            : <span><Coins size={16} /> {item.tokenValue || 0} tokens</span>}
        </div>
        {showStatus && <StatusBadge value={item.status} />}
        <Link className="btn btn-primary full" to={`/items/${item.itemId}`}>View details</Link>
      </div>
    </article>
  );
}
