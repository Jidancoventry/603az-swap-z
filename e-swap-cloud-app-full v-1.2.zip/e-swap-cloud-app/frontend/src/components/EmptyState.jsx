export default function EmptyState({ title = 'Nothing here yet', description = 'Create the first record or change your filters.' }) {
  return (
    <div className="empty-state">
      <h3>{title}</h3>
      <p>{description}</p>
    </div>
  );
}
