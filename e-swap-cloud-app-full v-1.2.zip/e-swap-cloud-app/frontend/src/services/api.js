import { fetchAuthSession } from 'aws-amplify/auth';
import { config } from '../config.js';
import {
  getMockItems,
  getMockRequests,
  saveMockItems,
  saveMockRequests
} from '../data/mockStore.js';

const wait = (ms = 250) => new Promise((resolve) => setTimeout(resolve, ms));

async function getJwtToken() {
  if (config.useMocks) return 'mock-jwt-token';
  try {
    const session = await fetchAuthSession();
    // The ID token includes name/email claims and its aud claim matches the Cognito app client.
    return session.tokens?.idToken?.toString() ?? '';
  } catch {
    return '';
  }
}

async function request(path, options = {}) {
  if (!config.apiBaseUrl) {
    throw new Error('VITE_API_BASE_URL is missing. Add the API Gateway URL to .env.local.');
  }

  const headers = { ...options.headers };
  if (!(options.body instanceof FormData) && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }

  if (options.auth !== false) {
    const token = await getJwtToken();
    if (token) headers.Authorization = `Bearer ${token}`;
  }

  const response = await fetch(`${config.apiBaseUrl}${path}`, {
    ...options,
    headers
  });

  const contentType = response.headers.get('content-type') ?? '';
  const body = contentType.includes('application/json')
    ? await response.json()
    : await response.text();

  if (!response.ok) {
    const message = typeof body === 'string'
      ? body
      : body?.message || body?.error || `Request failed with status ${response.status}`;
    const error = new Error(message);
    error.status = response.status;
    error.details = body;
    throw error;
  }

  return body;
}

function currentMockUser() {
  const stored = localStorage.getItem('eswap_mock_user_v2');
  return stored ? JSON.parse(stored) : null;
}

function matchesFilters(item, filters) {
  if (item.status !== 'Active') return false;
  const search = filters.search?.trim().toLowerCase();
  if (search) {
    const haystack = `${item.title} ${item.description} ${item.category} ${item.location}`.toLowerCase();
    if (!haystack.includes(search)) return false;
  }
  if (filters.category && filters.category !== 'All' && item.category !== filters.category) return false;
  if (filters.condition && filters.condition !== 'All' && item.condition !== filters.condition) return false;
  if (filters.actionType && filters.actionType !== 'All' && item.actionType !== filters.actionType) return false;
  if (filters.location && !item.location.toLowerCase().includes(filters.location.toLowerCase())) return false;
  return true;
}

function dataUrlFromFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error('Could not read the selected image.'));
    reader.readAsDataURL(file);
  });
}

export const api = {
  async health() {
    if (config.useMocks) return { status: 'ok', mode: 'mock' };
    return request('/health', { auth: false });
  },

  async getItems(filters = {}) {
    if (config.useMocks) {
      await wait();
      return getMockItems()
        .filter((item) => matchesFilters(item, filters))
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    }

    const params = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value && value !== 'All') params.set(key, value);
    });
    const suffix = params.toString() ? `?${params.toString()}` : '';
    return request(`/items${suffix}`, { auth: false });
  },

  async getItem(itemId) {
    if (config.useMocks) {
      await wait();
      const item = getMockItems().find((entry) => entry.itemId === itemId);
      if (!item) throw new Error('Item not found.');
      return item;
    }
    return request(`/items/${encodeURIComponent(itemId)}`, { auth: false });
  },

  async getMyItems() {
    if (config.useMocks) {
      await wait();
      const user = currentMockUser();
      return getMockItems()
        .filter((item) => item.ownerId === user?.userId)
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    }
    return request('/my-items');
  },

  async createUploadUrl(file) {
    if (config.useMocks) {
      return {
        uploadUrl: '',
        imageKey: `mock/${Date.now()}-${file.name}`,
        mockImageUrl: await dataUrlFromFile(file)
      };
    }

    return request('/uploads/presign', {
      method: 'POST',
      body: JSON.stringify({
        fileName: file.name,
        contentType: file.type,
        size: file.size
      })
    });
  },

  async uploadFile(file, uploadUrl) {
    if (config.useMocks) return;

    const response = await fetch(uploadUrl, {
      method: 'PUT',
      headers: {
        'Content-Type': file.type
      },
      body: file
    });

    if (!response.ok) {
      throw new Error(`Image upload failed with status ${response.status}.`);
    }
  },

  async createItem(payload) {
    if (config.useMocks) {
      await wait(350);
      const user = currentMockUser();
      if (!user) throw new Error('Please log in before creating a listing.');

      const now = new Date().toISOString();
      const item = {
        ...payload,
        itemId: `itm-${crypto.randomUUID()}`,
        ownerId: user.userId,
        ownerName: user.name,
        status: 'Active',
        createdAt: now,
        updatedAt: now
      };
      saveMockItems([item, ...getMockItems()]);
      return item;
    }

    return request('/items', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },

  async updateItem(itemId, payload) {
    if (config.useMocks) {
      await wait();
      const user = currentMockUser();
      const items = getMockItems();
      const index = items.findIndex((entry) => entry.itemId === itemId);
      if (index < 0) throw new Error('Item not found.');
      if (items[index].ownerId !== user?.userId && user?.role !== 'Admin') {
        throw new Error('You can update only your own listings.');
      }
      items[index] = { ...items[index], ...payload, updatedAt: new Date().toISOString() };
      saveMockItems(items);
      return items[index];
    }

    return request(`/items/${encodeURIComponent(itemId)}`, {
      method: 'PATCH',
      body: JSON.stringify(payload)
    });
  },

  async deleteItem(itemId) {
    if (config.useMocks) {
      await wait();
      const user = currentMockUser();
      const items = getMockItems();
      const item = items.find((entry) => entry.itemId === itemId);
      if (!item) throw new Error('Item not found.');
      if (item.ownerId !== user?.userId && user?.role !== 'Admin') {
        throw new Error('You can delete only your own listings.');
      }
      saveMockItems(items.filter((entry) => entry.itemId !== itemId));
      return { deleted: true, itemId };
    }

    return request(`/items/${encodeURIComponent(itemId)}`, { method: 'DELETE' });
  },

  async createRequest(payload) {
    if (config.useMocks) {
      await wait();
      const user = currentMockUser();
      const item = getMockItems().find((entry) => entry.itemId === payload.itemId);
      if (!item) throw new Error('Item not found.');
      if (item.ownerId === user?.userId) throw new Error('You cannot request your own listing.');

      const requestItem = {
        requestId: `req-${crypto.randomUUID()}`,
        itemId: item.itemId,
        itemTitle: item.title,
        requesterId: user.userId,
        requesterName: user.name,
        ownerId: item.ownerId,
        requestType: payload.requestType,
        message: payload.message,
        status: 'Pending',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      saveMockRequests([requestItem, ...getMockRequests()]);
      return requestItem;
    }

    return request('/requests', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },

  async getMyRequests() {
    if (config.useMocks) {
      await wait();
      const user = currentMockUser();
      return getMockRequests()
        .filter((entry) => entry.requesterId === user?.userId || entry.ownerId === user?.userId)
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    }
    return request('/my-requests');
  },

  async updateRequest(requestId, status) {
    if (config.useMocks) {
      await wait();
      const requests = getMockRequests();
      const index = requests.findIndex((entry) => entry.requestId === requestId);
      if (index < 0) throw new Error('Request not found.');
      requests[index] = { ...requests[index], status, updatedAt: new Date().toISOString() };
      saveMockRequests(requests);
      return requests[index];
    }
    return request(`/requests/${encodeURIComponent(requestId)}`, {
      method: 'PATCH',
      body: JSON.stringify({ status })
    });
  },

  async getAdminItems() {
    if (config.useMocks) {
      await wait();
      return getMockItems().sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    }
    return request('/admin/items');
  },

  async moderateItem(itemId, status) {
    if (config.useMocks) {
      return this.updateItem(itemId, { status });
    }
    return request(`/admin/items/${encodeURIComponent(itemId)}`, {
      method: 'PATCH',
      body: JSON.stringify({ status })
    });
  }
};
